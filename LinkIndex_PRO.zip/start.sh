#!/bin/bash
echo "==================================="
echo "    LinkIndex PRO - Iniciando..."
echo "==================================="
echo ""
echo "Instalando dependências..."
npm install
echo ""
echo "Iniciando servidor..."
echo "Acesse: http://localhost:3000"
echo ""
node server.js
